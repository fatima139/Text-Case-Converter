Text Case Converter

Description:
Text Case Converter is a Chrome extension that allows you to convert text cases directly from your browser. With this extension, you can easily convert text to uppercase, lowercase, sentence case, and title case with just a click of a button.

Installation:
1. Clone or download this repository to your local machine.
2. Open Google Chrome and go to chrome://extensions/.
3. Enable Developer mode by toggling the switch in the top-right corner.
4. Click on "Load unpacked" and select the directory where you cloned or downloaded this repository.
5. The Text Case Converter extension should now be installed and ready to use.

Usage:
1. Click on the extension icon in the Chrome toolbar to open the popup interface.
2. Enter or paste text into the text area.
3. Click on the desired conversion button (Uppercase, Lowercase, Sentence case, Title Case) to convert the text.
4. The converted text will be displayed in the text area and automatically copied to the clipboard.
5. Click on the "Clear" button to clear the text area and start over.

License:
Text Case Converter is licensed under the GNU General Public License v3.0 (GPL-3.0). See the LICENSE file for more details.
